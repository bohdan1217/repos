<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>test</title>

    <!-- Bootstrap -->
    <link rel="stylesheet" href="css/font-awesome.css">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" media="all" href="fancybox/jquery.fancybox.css">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>





  <div class="container" style="padding-top: 50px">
    <div class="navbar navbar-default" role="navigation">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand hidden-xs" href="#" style=" background-color: rgb(86, 204, 200); width: 60px; margin-right: 30px"><img src="images/MenuIcon.png"></a>
          <a class="navbar-brand visible-xs">Головне меню</a>
        </div>
        <div class="navbar-collapse collapse">
          <ul class="nav navbar-nav link">
            <li><a href="#">Home</a></li>
            <li><a href="#">Store</a></li>
            <li><a href="#" style="color: rgb(86, 204, 200);">Blog</a></li>
            <li><a href="#">About</a></li>
            <li><a href="#">Contact</a></li>
          </ul>


          <ul class="nav navbar-nav navbar-right">
            <li><a class="" href="#"><img src="images/Searchicon.png"></a></li>
            <li><a class="" href="#"><img src="images/Facebook%20con1.png"></a></li>
            <li><a class="" href="#"><img src="images/TwitterIcon1.png"></a></li>
            <li><a class="" href="#"><img src="images/GIconcopy.png"></a></li>
            <li><a class="modalbox" href="#inline"><img src="images/LoginIcon.png"></a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>


  <!-- hidden inline form -->
  <div id="inline">
    <h2>Ask a Question</h2>

    <form id="contact" name="contact" action="#" method="post">
      <input type="text" id="name" name="name" class="txt form-control" placeholder="Your name" required>
      <input type="email" id="email" name="email" class="txt form-control" style="border-color: rgb(75, 199, 199);" placeholder="Your email" required>
      <textarea id="msg" name="msg" class="txtarea form-control" rows="5" placeholder="Your question" required></textarea>
      <button id="send" class="btn btn-default">Submit</button>
    </form>
  </div>


  <!-- /контейнер -->
  <div class="container">
  <div class="col-lg-6 col-md-6" style="margin: 0;padding: 0">
    <!--    меню-->
    <div class="col-lg-6 col-md-6" style="margin: 0;padding: 0">


      <div class="navbar navbar-default" role="navigation">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse2">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        </div>
      <div id="Menu" class="navbar-collapse2">
      <ul class="nav nav-list">
        <li><a href="#"><img src="images/Home.png"><span>Home</span></a></li>
        <li><a href="#"><img src="images/Shop.png"><span>Store</span></a></li>
        <li class="active"><a href="#"><img src="images/Noteicon.png"><span style="color: white">Blog</span></a></li>
        <li><a href="#"><img src="images/Usersicon.png"><span>Community</span></a></li>
        <li><a href="#"><img src="images/Trophyicon.png"><span>Contests</span></a></li>
        <li><a href="#"><img src="images/Infoicon.png"><span>About</span></a></li>
        <li><a href="#"><img src="images/EmailIcon.png"><span>Contact</span></a></li>
      </ul>
      </div>


      <!--контакти-->
      <div class="col-lg-12 col-md-12 col-xs-12 " id="contact_id" >
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" id="margin_top">
        <div class="col-sm-2 col-xs-2 col-lg-2 col-md-2">
          <span><img src="images/phone.png"></span>
        </div>
        <div class="col-sm-10 col-xs-10" id="contact_text">
          (912) 555-1234<br>
          (912) 555-5678
        </div>
        </div>
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" id="margin_top">
        <div class="col-sm-2 col-xs-2">
          <span><img src="images/pointer.png"></span>
        </div>
        <div class="col-sm-10 col-xs-10" id="contact_text">
          1600 Pennsylvania<br>
          Ave NM.Washington<br>
          DC 20500, USA
        </div>
          </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" id="margin_top">
        <div class="col-sm-2 col-xs-2">
        <span><img src="images/email%20.png"></span>
        </div>
        <div class="col-sm-10 col-xs-10" id="contact_text">
          hello@website.com
          office@website.com
        </div>
            </div>
      </div>
    </div>
    </div>

    <!--submenu-->
    <div class="col-lg-6 col-md-6 col-xs-12" style="margin: 0;padding: 0">
      <div class="col-lg-12 col-md-12 col-xs-12" id="submenu">
        <p style="padding-top: 15px;"><a href="" class="colorblue">Tech</a><span style="float:right"><img src="images/arrow.png"></span></p>
        <p><a href="#" class="colorwhite">Software & Apps</a></p>
        <p><a href="#" class="colorwhite">Gadgets</p>
        <p><a href="#" class="colorwhite">Mobile</p>
      </div>
      <div class="col-lg-12 col-md-12 col-xs-12" id="submenu2">
        <p style="padding-top: 15px;"><a href="#" class="colorblue">Entertaiment</a><span style="float:right"><img src="images/arrow.png"></span></p>
        <p><a href="#" class="colorwhite">Film</a></p>
        <p><a href="#" class="colorwhite">Gaming</a></p>
        <p><a href="#" class="colorwhite">Music</a></p>
        <p><a href="#" class="colorwhite">Sport</a></p>
      </div>
      <div class="col-lg-12 col-md-12 col-xs-12" id="submenu">
        <p style="padding-top: 15px;"><a href="#" class="colorblue">Business</a><span style="float:right"><img src="images/arrow.png"></span></p>
        <p><a href="#" class="colorwhite">Jobs</p>
        <p><a href="#" class="colorwhite">Marketing</p>
        <p><a href="#" class="colorwhite">Media</p>
      </div>
      <div class="col-lg-12 col-md-12 col-xs-12" id="submenu">
        <p style="padding-top: 15px;"><a href="#" class="colorblue">Lifestyle</a><span style="float:right"><img src="images/arrow.png"></span></p>
        <p><a href="#" class="colorwhite">Home</a></p>
        <p><a href="#" class="colorwhite">Health & Fitmess</a></p>
        <p><a href="#" class="colorwhite">Travel & Leisure</a></p>
      </div>
    </div>
  </div>



    <!--block2-->
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12" id="media">

      <!-- social menu-->
      <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12" id="socialmenu">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" id="margin_top">
          <div class="col-sm-2 col-lg-2 col-md-2 col-xs-2">
            <a href="#" target="_blank"><img src="images/Fb1.png"></a>
          </div>
          <div class="col-lg-offset-1 col-md-offset-1 col-sm-offset-1 col-sm-4 col-lg-9 col-md-9 col-xs-10" id="socialmenutext">
            Facebook
          </div>
        </div>
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" id="margin_top">
          <div class="col-sm-2 col-lg-2 col-md-2 col-xs-2">
            <a href="#" target="_blank"><img src="images/Twitter_Selected.png"></a>
          </div>
          <div class="col-lg-offset-1 col-md-offset-1 col-sm-offset-1 col-sm-4 col-lg-9 col-md-9 col-xs-10" id="socialmenutext" style="color: rgb(86, 204, 200);">
            Twitter
          </div>
        </div>
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" id="margin_top">
          <div class="col-sm-2 col-lg-2 col-md-2 col-xs-2">
            <a href="#" target="_blank"><img src="images/G+1.png"></a>
          </div>
          <div class="col-lg-offset-1 col-md-offset-1 col-sm-offset-1 col-sm-4 col-lg-9 col-md-9 col-xs-10" id="socialmenutext">
            Google +
          </div>
        </div>
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" id="margin_top">
          <div class="col-sm-2 col-lg-2 col-md-2 col-xs-2">
            <a href="#" target="_blank"><img src="images/Rss.png"></a>
          </div>
          <div class="col-lg-offset-1 col-md-offset-1 col-sm-offset-1 col-sm-4 col-lg-9 col-md-9 col-xs-10" id="socialmenutext">
            Rss Feeds
          </div>
        </div>
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" id="margin_top">
          <div class="col-sm-2 col-lg-2 col-md-2 col-xs-2">
            <a href="#" target="_blank"><img src="images/Pinterest.png"></a>
          </div>
          <div class="col-lg-offset-1 col-md-offset-1 col-sm-offset-1 col-sm-4 col-lg-9 col-md-9 col-xs-10" id="socialmenutext">
            Pinterest
          </div>
        </div>
      </div>


      <!--facebook and twitter-->
      <div class="col-lg-6 col-md-6 col-xs-12" id="media_ft">
        <!--facebook-->
        <div class="col-lg-12 col-md-12 col-xs-12" id="facebookdiv">
          <div class="col-sm-12" style="padding-top: 25px">
            <span ><img src="images/Facebook.png"></span>
          </div>
          <div class="col-sm-12" id="contact_text_tf">
            <div class="col-sm-2 col-xs-2" style="padding-left: 0">
              156K
            </div>
            <div class="col-sm-offset-4 col-sm-6 col-md-offset-4 col-md-6 col-xs-offset-4 col-xs-6" style="text-align: right">
              Follow <img src="images/Follow.png">
            </div>

          </div>
        </div>
        <!--twitter-->
        <div class="col-lg-12 col-md-12 col-xs-12" id="twiterdiv">
          <div class="col-sm-12" style="padding-top: 25px">
            <span><img src="images/Twitter_C.png"></span>
          </div>

          <div class="col-sm-12" id="contact_text_tf">
            <div class="col-sm-2 col-xs-2" style="padding-left: 0">
              89K
            </div>
            <div class="col-sm-offset-4 col-sm-8 col-md-offset-3 col-md-7 col-xs-offset-4 col-xs-6" style="text-align: right">
            Following <img src="images/Followuser.png">
            </div>
          </div>
        </div>
      </div>
      <!--sign in-->
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" id="signin">
        <h2>Sign In</h2>
        <p style="margin-top: -10px">Just select your favorite social network to get started</p>
        <p style="padding-top: 1px">
          <a href="#" target="_blank"><img src="images/Fb.png"></a>
          <a href="#" target="_blank"><img src="images/Twitter.png"></a>
          <a href="#" target="_blank"><img src="images/G+.png"></a>
          <a href="#" target="_blank"><img src="images/link.png"></a>
        </p>
      </div>
      <!--join-->
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" id="join">
        <h2>Join the Newsletter </h2>
        <p style="margin-top: -20px">Sign up for our personalized daily newslett</p>
        <form class="navbar-form navbar-center" role="search" action="" method="post">
          <div class="col-sm-12 col-md-12 col-lg-12 col-xs-12" >
          <div class="col-sm-10 col-xs-9 col-md-8 col-lg-8" >
            <input type="text" class="form-control" id="border" placeholder="Enter email address" required >
          </div>
          <div class="col-sm-2 col-xs-3">
          <button type="submit" class="btn btn-default" id="button">SIGN UP</button>
            </div>
          </div>
        </form>
      </div>
    </div>




    <script src="http://ajax.googleapis.com/ajax/libs/jquery/3.0.0/jquery.min.js"></script>
    <script src="js/responsiveslides.min.js"></script>
    <script>
      var jquery_3_0_0 = jQuery;
    </script>
    <script>
      (function(){
        var $ = jQuery = jquery_3_0_0 ;
      // You can also use "$(window).load(function() {"
      $(function () {


        // Slideshow 4
        $("#slider4").responsiveSlides({
          auto: false,
          pager: false,
          nav: true,
          speed: 500,
          namespace: "callbacks",
          before: function () {
            $('.events').append("<li>before event fired.</li>");
          },
          after: function () {
            $('.events').append("<li>after event fired.</li>");
          }
        });

      });
      })();
    </script>



    <!-- Slideshow -->
    <div class="callbacks_container" style="margin-top: 10px">
      <ul class="rslides" id="slider4">
        <li>
          <img src="images/1.jpg" alt="">
        </li>
        <li>
          <img src="images/2.jpg" alt="">

        </li>
        <li>
          <img src="images/3.jpg" alt="">
        </li>
      </ul>
    </div>

  </div>  <!--end container-->


  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
  <script type="text/javascript" src="fancybox/jquery.fancybox.js"></script>
  <script>
    var jquery_1_8_3 = jQuery;
  </script>


  <!-- basic fancybox setup -->
  <script type="text/javascript">
    (function(){
      var $ = jQuery = jquery_1_8_3 ;

    function validateEmail(email) {
      var reg = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      return reg.test(email);
    }

    $(document).ready(function() {
      $(".modalbox").fancybox();
      $("#contact").submit(function() { return false; });


      $("#send").on("click", function(){
        var nameval  = $("#name").val();
        var emailval  = $("#email").val();
        var msgval    = $("#msg").val();
        var nameglen    = nameval.length;
        var msglen    = msgval.length;
        var mailvalid = validateEmail(emailval);

        if(nameglen < 3) {
          $("#name").addClass("error");
        }
        else if(nameglen >= 5){
          $("#name").removeClass("error");
        }



        if(mailvalid == false) {
          $("#email").addClass("error");
        }
        else if(mailvalid == true){
          $("#email").removeClass("error");
        }



        if(msglen < 4) {
          $("#msg").addClass("error");
        }
        else if(msglen >= 4){
          $("#msg").removeClass("error");
        }

        if(mailvalid == true && msglen >= 4) {

          $("#send").replaceWith("<em>відправка...</em>");

          $.ajax({
            type: 'POST',
            url: 'sendmessage.php',
            data: $("#contact").serialize(),
            success: function(data) {
              if(data == "true") {
                $("#contact").fadeOut("fast", function(){
                  $(this).before("<p><strong>Вітаємо! Ваше повідомлення відправлено  :)</strong></p>");
                  setTimeout("$.fancybox.close()", 1000);
                });
              }
            }
          });
        }
      });
    });
    })();
  </script>




  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>