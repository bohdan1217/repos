<?php
$sendto   = "bohdan-gordiychuk@bk.ru";
$username = $_POST['name'];
$usermail = $_POST['email'];
$content  = nl2br($_POST['msg']);
// заголовок повідомлення
$subject  = "Нове повідомлення";
$headers  = "From: " . strip_tags($usermail) . "\r\n";
$headers .= "Reply-To: ". strip_tags($usermail) . "\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html;charset=utf-8 \r\n";
// Форма
$msg  = "<html><body style='font-family:Arial,sans-serif;'>";
$msg .= "<h2 style='font-weight:bold;border-bottom:1px dotted #ccc;'>Нове повідомлення</h2>\r\n";
$msg .= "<p><strong>Імя:</strong> ".$usermail."</p>\r\n";
$msg .= "<p><strong>Email:</strong> ".$usermail."</p>\r\n";
$msg .= "<p><strong>Повідомлення:</strong> ".$content."</p>\r\n";
$msg .= "</body></html>";

// відправка повідомлення
if(@mail($sendto, $subject, $msg, $headers)) {
	echo "true";
} else {
	echo "false";
}

?>